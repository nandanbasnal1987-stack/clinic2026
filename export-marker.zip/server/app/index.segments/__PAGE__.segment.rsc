1:"$Sreact.fragment"
2:"/_next/static/chunks/2n9_9xd704-iy.js"
3:I[93983,["$2"],"default"]
4:I[39756,["$2"],"default"]
5:I[37457,["$2"],"default"]
:HL["/_next/static/chunks/3jukgwvyit_ml.css","style"]
:HL["https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,400;0,500;0,600;0,700;1,400&display=swap","style"]
:HL["https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap","style"]
:HL["https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600&family=Inter:wght@400;500;600;700&display=swap","style"]
:HL["https://fonts.googleapis.com/css2?family=Poppins:wght@400;500&family=Inter:wght@400;500;600;700&display=swap","style"]
:HL["https://fonts.googleapis.com/css2?family=Lato:wght@400;700;900&family=Poppins:wght@400;500;600&display=swap","style"]
:HL["https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap","style"]
:HL["https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap","style"]
:HL["https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600&display=swap","style"]
:HL["https://fonts.googleapis.com/css2?family=Poppins:wght@400;500&family=Inter:wght@500;700&display=swap","style"]
:HL["https://fonts.googleapis.com/css2?family=Inter:wght@400;500;700&display=swap","style"]
:HL["https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,600;1,400&family=Roboto:wght@400;500&display=swap","style"]
a:X
b:[["children",{"s":"__PAGE__","h":160,"d":{"r":"$Lc","p":"$@d","v":null,"s":"$a"}}]]
0:{"t":{"t":{"s":"","h":80,"d":{"r":["$","$1","c",{"children":[[["$","link","0",{"rel":"stylesheet","href":"/_next/static/chunks/3jukgwvyit_ml.css","precedence":"next"}],["$","script","script-0",{"src":"/_next/static/chunks/2n9_9xd704-iy.js","async":true}]],["$","html",null,{"lang":"en","suppressHydrationWarning":true,"children":[["$","head",null,{"children":[["$","link",null,{"rel":"preconnect","href":"https://fonts.googleapis.com"}],["$","link",null,{"rel":"preconnect","href":"https://fonts.gstatic.com","crossOrigin":"anonymous"}],[["$","link","https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,400;0,500;0,600;0,700;1,400&display=swap",{"href":"https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,400;0,500;0,600;0,700;1,400&display=swap","rel":"stylesheet"}],["$","link","https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap",{"href":"https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap","rel":"stylesheet"}],["$","link","https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600&family=Inter:wght@400;500;600;700&display=swap",{"href":"https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600&family=Inter:wght@400;500;600;700&display=swap","rel":"stylesheet"}],["$","link","https://fonts.googleapis.com/css2?family=Poppins:wght@400;500&family=Inter:wght@400;500;600;700&display=swap",{"href":"https://fonts.googleapis.com/css2?family=Poppins:wght@400;500&family=Inter:wght@400;500;600;700&display=swap","rel":"stylesheet"}],["$","link","https://fonts.googleapis.com/css2?family=Lato:wght@400;700;900&family=Poppins:wght@400;500;600&display=swap",{"href":"https://fonts.googleapis.com/css2?family=Lato:wght@400;700;900&family=Poppins:wght@400;500;600&display=swap","rel":"stylesheet"}],["$","link","https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap",{"href":"https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600;700&display=swap","rel":"stylesheet"}],["$","link","https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap",{"href":"https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap","rel":"stylesheet"}],["$","link","https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600&display=swap",{"href":"https://fonts.googleapis.com/css2?family=Poppins:wght@400;500;600&display=swap","rel":"stylesheet"}],["$","link","https://fonts.googleapis.com/css2?family=Poppins:wght@400;500&family=Inter:wght@500;700&display=swap",{"href":"https://fonts.googleapis.com/css2?family=Poppins:wght@400;500&family=Inter:wght@500;700&display=swap","rel":"stylesheet"}],["$","link","https://fonts.googleapis.com/css2?family=Inter:wght@400;500;700&display=swap",{"href":"https://fonts.googleapis.com/css2?family=Inter:wght@400;500;700&display=swap","rel":"stylesheet"}],["$","link","https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,600;1,400&family=Roboto:wght@400;500&display=swap",{"href":"https://fonts.googleapis.com/css2?family=Poppins:ital,wght@0,600;1,400&family=Roboto:wght@400;500&display=swap","rel":"stylesheet"}]]]}],["$","body",null,{"children":[["$","$L3",null,{}],["$","$L4",null,{"parallelRouterKey":"children","template":["$","$L5",null,{}],"notFound":[[["$","title",null,{"children":"404: This page could not be found."}],["$","div",null,{"style":{"fontFamily":"system-ui,\"Segoe UI\",Roboto,Helvetica,Arial,sans-serif,\"Apple Color Emoji\",\"Segoe UI Emoji\"","height":"100vh","textAlign":"center","display":"flex","flexDirection":"column","alignItems":"center","justifyContent":"center"},"children":["$","div",null,{"children":[["$","style",null,{"dangerouslySetInnerHTML":{"__html":"body{color:#000;background:#fff;margin:0}.next-error-h1{border-right:1px solid rgba(0,0,0,.3)}@media (prefers-color-scheme:dark){body{color:#fff;background:#000}.next-error-h1{border-right:1px solid rgba(255,255,255,.3)}}"}}],"$L6","$L7"]}]}]],[]]}],"$L8"]}]]}]]}],"p":"$@9","v":null,"s":"$a"},"c":"$Qb"},"h":{"r":"$Le","p":"$@f","v":null,"s":"$a"}},"a":"$@10","u":"$@11","b":"LCpyqmJnVc1DANX7HBC0v"}
12:I[87392,["$2"],"default"]
13:"/_next/static/chunks/2ueyz0rtm7fh5.js"
14:I[55415,["$2","$13"],"default"]
15:I[93451,["$2","$13"],"default"]
16:I[66816,["$2","$13"],"default"]
17:I[10822,["$2","$13"],"default"]
18:I[46940,["$2","$13"],"default"]
19:I[50630,["$2","$13"],"default"]
1a:I[5500,["$2","$13"],"Image"]
1b:I[53632,["$2","$13"],"default"]
1c:I[78125,["$2","$13"],"default"]
1d:I[12382,["$2","$13"],"default"]
1e:I[56941,["$2","$13"],"default"]
1f:I[68050,["$2","$13"],"default"]
20:I[29854,["$2","$13"],"default"]
21:I[97367,["$2"],"OutletBoundary"]
22:"$Sreact.suspense"
24:"ViewportBoundary"
25:I[97367,["$2"],"$24"]
26:"MetadataBoundary"
27:I[97367,["$2"],"$26"]
:HL["/_next/static/chunks/1ujcnmsfayjqv.css","style"]
6:["$","h1",null,{"className":"next-error-h1","style":{"display":"inline-block","margin":"0 20px 0 0","padding":"0 23px 0 0","fontSize":24,"fontWeight":500,"verticalAlign":"top","lineHeight":"49px"},"children":404}]
7:["$","div",null,{"style":{"display":"inline-block"},"children":["$","h2",null,{"style":{"fontSize":14,"fontWeight":400,"lineHeight":"49px","margin":0},"children":"This page could not be found."}]}]
8:["$","$L12",null,{}]
c:["$","$1","c",{"children":[[["$","$L14",null,{}],["$","main",null,{"id":"page-main","children":[["$","$L15",null,{}],["$","$L16",null,{}],["$","$L17",null,{}],["$","$L18",null,{}],["$","$L19",null,{}],["$","div",null,{"className":"banner","children":["$","$L1a",null,{"src":"/Images/transition_img.svg","alt":"Transition illustration","width":0,"height":0,"sizes":"100vw","style":{"width":"100%","height":"auto"}}]}],["$","$L1b",null,{}],["$","$L1c",null,{}],["$","$L1d",null,{}],["$","$L1e",null,{}],["$","$L1f",null,{}],["$","$L20",null,{}]]}]],[["$","link","0",{"rel":"stylesheet","href":"/_next/static/chunks/1ujcnmsfayjqv.css","precedence":"next"}],["$","script","script-0",{"src":"/_next/static/chunks/2ueyz0rtm7fh5.js","async":true}]],["$","$L21",null,{"children":["$","$22",null,{"name":"Next.MetadataOutlet","children":"$@23"}]}]]}]
e:["$","$1","h",{"children":[null,["$","$L25",null,{"children":[["$","meta","0",{"charSet":"utf-8"}],["$","meta","1",{"name":"viewport","content":"width=device-width, initial-scale=1, viewport-fit=cover"}]]}],["$","$L27",null,{"children":[["$","div",null,{"hidden":true,"children":["$","$22",null,{"name":"Next.Metadata","children":[["$","title","0",{"children":"Augastam Clinical – AI-Native Clinical care"}],["$","meta","1",{"name":"description","content":"Smarter, connected healthcare with Augastam Clinical — bringing consultations, clinical documentation, and AI-powered tools together to support better patient care at every stage."}]]}]}],null]}],null]}]
23:null
11:true
a:300
a:C
10:0
f:"$undefined"
d:"$undefined"
9:"$undefined"
